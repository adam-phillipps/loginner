require_relative './cheater_stuff'

module Smash
  class FtFeServer
    include Smash::CheaterStuff

    attr_accessor :clues

    def initialze(**opts)
      @project_root = File.expand_path(__FILE__)
      @message = String.new
    end

    def self.build(**opts)
      client = new
      client.inject_workflow(client.workflow_description)
      client
    end

    def self.create(**opts); self.build(**opts); end

    def get_clues(file = 'test.csv')
      # do some stuff to get some clues
    end

    def build_client
      current_clues = cheater_clues.shift
      @current_client = Smash::ClientClassBuilder.build_client(current_clues, client_workflow_description)
    end

    # Make the client do what it does
    def deploy_client
      until(@current_client.done?)
        @current_client.next!
      end
    end

    # organize the clues from the csv.  this might not be needed in production
    # because the interrogator side does this sort of thing
    def organize_clues
      cheater_clues
    end

    def done?
      cheater_clues.empty? || super
    end

    def financial_institutions
      @clues.map do |row|
        row.fetch(row.headers.select { |h| /fiName/ =~ h }.first)
      end.uniq.compact
    end

    def to_csv(file)
      storage_search(:local, file) { |f| f.split(',') }
    end

    def to_csv_table(csv, col_num)
      headers = csv[0..(col_num - 1)]
      rows = []
      csv[col_num..-1].each_slice(col_num) do |cells|
        rows << CSV::Row.new(headers, cells)
      end
      CSV::Table.new(rows)
    end

    def next!
      self.public_send "#{current_state.events.first.first}!"
    end
  end
end

server = Smash::FtFeServer.create

until(server.done?)
  server.next!
end
puts 'all done, i suppose'
