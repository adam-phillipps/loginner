require 'site_prism'
require 'capybara'
require 'capybara/dsl'
require 'capybara'
require 'selenium-webdriver'
require 'cloud_powers'
require 'byebug'
require 'brain_func'

module Smash
  module ClientInstanceIncludes
    def next!
      public_send "#{current_state.events.first.first}!"
    end

    def available_elements
      self.class.mapped_items.select do |mapped_element|
        public_send "has_#{mapped_element}?"
      end
    end

    def fill_out_available_fields
      buttons = []
      available_elements.each do |el|
        if /button$/ =~ el
            buttons << el
        else
          public_send(el).set 'hey'
        end
      end
      buttons.each do |button|
        public_send(button).click
        save_and_open_screenshot
      end
    end
  end

  module ClientClassIncludes
    def self.extended(base)
      base.send :include, Smash::BrainFunc
    end

    attr_accessor :clues, :url

    def initialize(url, *clues)
      @url = url
      @clues = clues
    end

    # Take a set of <tt>CSV::Row</tt>s and turn them into individual
    # +elements+ on the class.
    def set_custom_elements(**clues)
      clues.each do |el_name, selector|
        public_send :element, el_name, selector
      end
    end
  end
end
